package adc;

import java.awt.Color;
import java.awt.GridBagConstraints;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

/**
 *
 * @author www.edsim51.com
 */
class Gui extends JPanel {
    
    private ADC adc;
    
    Gui(boolean small, Board board) {
        
        adc = new ADC(board);
        
        this.setBackground(new Color(204, 255, 102));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        JScrollPane sp = new JScrollPane(adc.getGraphics());
        this.add(sp);
        
    }
      
    void setSize(boolean small) {
        adc.getGraphics().setSize(small);
    }
    
    ADC getADC() {
        return adc;
    }
    
}