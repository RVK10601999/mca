package switch_and_led;

import edsim51sh.TargetBoard;

/**
 *
 * @author www.edsim51.com
 */
public class Board extends TargetBoard {
    
    private Gui gui;
    
    public Board() {
        
        /** Create the GUI, size small (true), passing a reference to this
         *  target board (see the Gui constructor comments for details on why
         *  a reference the target board is needed).
         */        
        gui = new Gui(true, this);  
        
        /** Call the TargetBoard's init() method (see TargetBoard's comments
         *  for details.
         */
        this.init(gui, "Example Target Board", "1.0.0");
        
        /** Set the port pin descriptions for the LED and Switch - see
         *  TargetBoard's comments for details.
         */
        this.setPortPinDescription(gui.led.PORT_NUMBER, gui.led.PIN_NUMBER, "LED");
        this.setPortPinDescription(gui.sw.PORT_NUMBER, gui.sw.PIN_NUMBER, "SWITCH");

    }
    
    public void setTargetBoardGraphicsSize(boolean small) {
        gui.setSize(small);
    }
    
    public void updateTargetBoardGraphics() {
        gui.led.updateGraphics();
    }
    
    public void updatePortPins() {
        
        /** Update the LED to reflect the state of the port pin. */
        if (this.readPortPin(gui.led.PORT_NUMBER, gui.led.PIN_NUMBER) == 1) {
            gui.led.turnOff();
        } else {
            gui.led.turnOn();
        }
        
        /** If the switch is closed, the port pin is pulled low, no matter the
         *  state of the port latch.
         *  Note: There is no need to check to see if the switch is open. If it
         *  is open, the state of the port pin is decided by the state of the
         *  port latch, and this is taken care of by the 8051 (and therefore by
         *  EdSim51) and not by the target board. */
        if (gui.sw.isClosed()) {
            this.clearPortPin(gui.sw.PORT_NUMBER, gui.sw.PIN_NUMBER);
        }
    }
    
}