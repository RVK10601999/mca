package switch_and_led;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;

/**
 *
 * @author www.edsim51.com
 */
public class Switch extends JButton {
    
    // Switch is connected to P1.1
    static final int PORT_NUMBER = 1;
    static final int PIN_NUMBER = 1;
    
    // The small and large dimensions and fonts for the Switch graphic.
    private Font smallFont = new Font("Courier New", 1, 12);
    private Font largeFont = new Font("Courier New", 1, 18);
    private Dimension smallD = new Dimension(84, 24);
    private Dimension largeD = new Dimension(126, 36);
    
    private boolean open = true;    // default: Switch is open
    
    /** Since the Switch is an input device, a reference to the target board is
     *  needed in order to update the board's port pins.
     */
    private Board board;
    
    /** Initialises the Switch graphic to the given size and adds a mouse
     *  listener.
     *  A reference to the target board instance is required as this Switch is
     *  an input device and therefore must be able to update the target
     *  board's port pins (P1.1, in this case).
     */
    Switch(boolean small, Board board) {
        setSize(small);
        this.board = board;
        this.setText("OPEN");
        this.setToolTipText("Connected to P" + PORT_NUMBER + "." + PIN_NUMBER);
        this.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent evt) {
                toggle(); // when the mouse is pressed, toggle the Switch
            }
        });
    }
    
    // Sets the graphic size to either small or large.
    void setSize(boolean small) {
        if (small) {
            this.setFont(smallFont);
            this.setPreferredSize(smallD);
        } else {
            this.setFont(largeFont);
            this.setPreferredSize(largeD);
        }
    }
    
    boolean isClosed() {
        return !open;
    }
    
    private void toggle() {
        if (open) {         // if it's open ...
            open = false;   // then close it
            this.setText("CLOSED");
            board.clearPortPin(PORT_NUMBER, PIN_NUMBER); // and clear the port pin
        } else {            // otherwise ...
            open = true;    // open it
            this.setText("OPEN");
            board.setPortPin(PORT_NUMBER, PIN_NUMBER);   // and set the port pin
            /** Note: setting the port pin is not guaranteed. If the 8051
             *  cleared the pin (ie: the pin's latch is 0) then it cannot be
             *  set. But the code here does not need to test for that situation;
             *  it can attempt to set the pin, but if the latch is 0, the pin
             *  will remain at 0.
             */
        }
    }
    
}