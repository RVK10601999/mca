package switch_and_led;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author www.edsim51.com
 */
public class Gui extends JPanel {

    // This very simple GUI contains one LED and one switch.
    Led led;
    Switch sw;

    /**
     * Sets the GUI size and adds the LED and Switch. A reference to the target
     * board instance is required as it must be passed to the Switch constructor
     * - see the Switch constructor comments for details.
     */
    Gui(boolean small, Board board) {

        Dimension d = new Dimension(400, 100);

        this.setLayout(new GridBagLayout());
        this.setMaximumSize(d);
        this.setMinimumSize(d);
        this.setPreferredSize(d);
        this.setBackground(new Color(204, 255, 102));

        led = new Led(small);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(20, 20, 20, 20);
        this.add(led, gbc);

        sw = new Switch(small, board);
        gbc.gridx = 1;
        gbc.gridy = 0;
        this.add(sw, gbc);

        gbc.gridx = 2;
        gbc.gridy = 0;
        this.add(new JLabel("Very simple target board with one LED and one switch."), gbc);

    }

    // This method will be used by the target board instance to set the GUI size.    
    void setSize(boolean small) {
        led.setSize(small);
        led.setSize(small);
        sw.setSize(small);
    }
}