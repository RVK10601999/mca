package switch_and_led;

import java.awt.Color;
import java.awt.Dimension;
import javax.swing.BorderFactory;
import javax.swing.JPanel;

/**
 *
 * @author www.edsim51.com
 */
class Led extends JPanel {
    
    // LED is connected to P1.0
    static final int PORT_NUMBER = 1;
    static final int PIN_NUMBER = 0;
    
    // The small and large dimensions for the LED graphic.    
    private Dimension smallSize = new Dimension(10, 10);
    private Dimension largeSize = new Dimension(15, 15);
    
    private boolean on = false;             // default: LED off
    
    private Color onColor = Color.RED;      // red when on
    private Color offColor = Color.WHITE;   // white when off
    
    /** Initialises the LED graphic to the given size.     
     */
    Led(boolean small) {
        this.setBackground(offColor);
        setBorder(BorderFactory.createLineBorder(Color.BLACK));
        setSize(small);
        this.setToolTipText("Connected to P" + PORT_NUMBER + "." + PIN_NUMBER);
    }
    
    // Sets the graphic size to either small or large.
    void setSize(boolean small) {
        if (small) {
            this.setMaximumSize(smallSize);
            this.setMinimumSize(smallSize);
            this.setPreferredSize(smallSize);
        } else {
            this.setMaximumSize(largeSize);
            this.setMinimumSize(largeSize);
            this.setPreferredSize(largeSize);
        }
    }
    
    void turnOn() {
        on = true;
    }
    
    void turnOff() {
        on = false;
    }
    
    void updateGraphics() {
        if (on) {
            this.setBackground(onColor);
        } else {
            this.setBackground(offColor);
        }
    }
    
}